package br.com.brazcubas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.brazcubas.model.Professor;
import br.com.brazcubas.model.Telefone;
import br.com.brazcubas.model.EntidadeDominio;

public class ProfessorDAO extends AbstractJdbcDAO{

	//tabela principal
		private static final String principal_name_table = "pessoa";
		private static final String principal_id_table = "pes_id";
		//subdivis�o
		private static final String name_table = "professor";
		private static final String id_table = "pro_id";
		//subdivis�o 2 - telefone
		private static final String sub2_name_table = "telefone";
		private static final String sub2_id_table = "tel_id";
		
		//Variaveis
		Telefone telefone = new Telefone();
		ArrayList<Telefone> telefones = new ArrayList<Telefone>();
		
		
		PreparedStatement pst = null;
		ResultSet rs = null;
	
	public ProfessorDAO() {
		super(name_table, id_table);
	}
	
	public ProfessorDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(EntidadeDominio entidadedominio) throws SQLException {
		//abrindo conex�o
				if(connection == null) {
					openConnection();
				}
				//Declarando Entidade de Dominio
				Professor professor = (Professor)entidadedominio;
				//Persistindo informa��es Pessoa
				try {
					connection.setAutoCommit(false);
					
					StringBuilder sql = new StringBuilder();
					//Constru��o de c�digo sql para inser��o no BD
					sql.append("INSERT INTO ");
					sql.append(principal_name_table);
					sql.append("(pes_cpf, pes_email, pes_nome, pes_isprof) ");
					sql.append("VALUES (?,?,?,?);");
					
					pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
					
					pst.setString(1, professor.getCpf());
					pst.setString(2, professor.getEmail());
					pst.setString(3, professor.getNome());
					pst.setBoolean(4, professor.isStatus());			
					
					pst.executeUpdate();
					//Obtendo chave prim�ria gerada no BD
					rs = pst.getGeneratedKeys();
					int cdgPessoa= 0;
					if(rs.next())
						cdgPessoa= rs.getInt(1);
					professor.setId(cdgPessoa);
					//comitando informa��es pessoais
					connection.commit();
			
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("Erro ao persistir PESSOA");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				} try {
										
					StringBuilder sql2 = new StringBuilder();
					//Constru��o de c�digo sql para inser��o no BD
					sql2.append("INSERT INTO ");
					sql2.append(name_table);
					sql2.append("(pes_id, pro_titulacao, pro_status)");
					sql2.append("VALUES (?,?,?);");
				
					pst = connection.prepareStatement(sql2.toString(), Statement.RETURN_GENERATED_KEYS);
				
					pst.setInt(1, professor.getId());
					pst.setString(2, professor.getTitulacao());
					pst.setBoolean(3, professor.isStatus());			
				
					pst.executeUpdate();

					rs = pst.getGeneratedKeys();
					int cdgProf= 0;
					if(rs.next())
						cdgProf= rs.getInt(1);
					professor.setCodigo(cdgProf);
					connection.commit();
				
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("Erro ao persistir Professor");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				}try {
					//Instanciando array de telefones
					telefones = professor.getTelefones();
					
					//adicionando telefone
					for (Telefone tels: telefones) { 
					
						StringBuilder sql2 = new StringBuilder();
						//Constru��o de c�digo sql para inser��o no BD
						sql2.append("INSERT INTO ");
						sql2.append(sub2_name_table);
						sql2.append("(pes_id, tel_tipo, tel_numero)");
						sql2.append("VALUES (?,?,?);");
					
						pst = connection.prepareStatement(sql2.toString(), Statement.RETURN_GENERATED_KEYS);
					
						pst.setInt(1, professor.getId());
						pst.setString(2, tels.getTipo());
						pst.setString(3, tels.getNumero());			
					
						pst.executeUpdate();

						rs = pst.getGeneratedKeys();
						int cdgTelefone= 0;
						if(rs.next())
							cdgTelefone= rs.getInt(1);
						tels.setCodigo(cdgTelefone);
						connection.commit();
					}//
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("Erro ao persistir TELEFONE");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				} finally {
					try {
						//fechando conex�o em caso de �xito da segunda opera��o 
						pst.close();
						connection.close();
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				}
				
			}//salvar
	@Override
	public void alterar(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
				if(connection == null) {
					openConnection();
				}
				//Casting Entidade de Dominio
				Professor professor = (Professor)entidadedominio;
				//Alterando dados de Pessoa
				try {
					connection.setAutoCommit(false);
					//Constru��o de c�digo sql para opera��o de altera��o no BD
					StringBuilder sql = new StringBuilder();
					
					sql.append("UPDATE ");
					sql.append(principal_name_table);
					sql.append(" SET ");
					sql.append("(pes_nome, pes_email)");
					sql.append(" = (?,?) ");
					sql.append("WHERE ");
					sql.append(principal_id_table);
					sql.append("=(?)");
					
					pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
					
					pst.setString(1, professor.getNome());
					pst.setString(2, professor.getEmail());
					pst.setInt(3, professor.getId());
					
					pst.executeUpdate();
					
					connection.commit();
					
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("ERRO AO ALTERAR INFORMA��ES DE PESSOA");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				} try {
					connection.setAutoCommit(false);
					
					StringBuilder sql = new StringBuilder();
					
					sql.append("UPDATE ");
					sql.append(name_table);
					sql.append(" SET ");
					sql.append("pro_titulacao");
					sql.append(" = (?) ");
					sql.append("WHERE ");
					sql.append(id_table);
					sql.append("=(?)");
					
					pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
					
					pst.setString(1, professor.getTitulacao());
					pst.setInt(2, professor.getCodigo());
					
					pst.executeUpdate();
					
					connection.commit();
					
				} catch (SQLException e) {
					try {
						connection.rollback();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				}try {
					//Instanciando array de telefones
					telefones = professor.getTelefones();
					
					//alterando telefones
					for (Telefone tels: telefones) {
					
					connection.setAutoCommit(false);
					
					StringBuilder sql = new StringBuilder();
					
					sql.append("UPDATE ");
					sql.append(sub2_name_table);
					sql.append(" SET ");
					sql.append("(tel_tipo, tel_numero)");
					sql.append(" = (?,?) ");
					sql.append("WHERE ");
					sql.append(sub2_id_table);
					sql.append("=(?)");
					
					pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
					
					pst.setString(1, tels.getTipo());
					pst.setString(2, tels.getNumero());
					pst.setInt(3, tels.getCodigo());
					
					pst.executeUpdate();
					
					connection.commit();
					}//for
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("Erro ao alterar telefone");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				} finally {
					try {
						pst.close();
						connection.close();
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				}
			}//alterar
	@Override
	public void excluir(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
				if(connection == null) {
					openConnection();
				}
				//Casting EntidadeDominio
				Professor professor = (Professor)entidadedominio;
				//Constru��o de comando SQL para opera��o de exclus�o
				try {
					connection.setAutoCommit(false);
					
					StringBuilder sql = new StringBuilder();
					
					sql.append("DELETE FROM ");
					sql.append(name_table);
					sql.append(" WHERE ");
					sql.append(id_table);
					sql.append("=(?)");
					
					pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
					
					pst.setInt(1, professor.getCodigo());
					
					pst.executeUpdate();
					
					connection.commit();
					
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("ERRO AO EXCLUIR PROFESSOR");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
				} try {
					//Alterando 'pes_isProf' para FALSE, ap�s exclus�o de professor
					//Desta forma caso 'professor' tamb�m seja aluno, seu registro nao ser� comprometido
					connection.setAutoCommit(false);
					//Constru��o de c�digo sql para altera��o de status na tabela 'PESSOA'
					StringBuilder sql = new StringBuilder();
					
					sql.append("UPDATE ");
					sql.append(principal_name_table);
					sql.append(" SET ");
					sql.append("pes_isprof");
					sql.append(" = (?) ");
					sql.append("WHERE ");
					sql.append(principal_id_table);
					sql.append("=(?)");
					
					pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
					
					pst.setBoolean(1, false);
					pst.setInt(2, professor.getId());
					
					pst.executeUpdate();
					
					connection.commit();
					
				} catch (SQLException e) {
					try {
						connection.rollback();
						System.out.println("Erro de altera��o de status");
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					e.printStackTrace();
					
					}finally {
					try {
						//Fechando conex�o caso haja �xito nas opera��es
						pst.close();
						connection.close();
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				}
				
			}//excluir
	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
				if(connection == null) {
					openConnection();
				}
				//Casting Entidade dom�nio para Aluno
				Professor professor = (Professor)entidadedominio;
				
				StringBuilder sql = new StringBuilder();
				
				sql.append("SELECT * FROM ");
				sql.append(principal_name_table);
				sql.append(" natural join ");
				sql.append(name_table);
				sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
				//Adiciona � busca o par�metro (pes_id)
				if(professor.getCodigo() > 0) {
					sql.append(" AND professor.pro_id = ");
					sql.append(professor.getCodigo());
				}
				//Adiciona � busca o par�metro (prof_titulacao)
				if(professor.getTitulacao() != null) {
					sql.append(" AND professor.pro_titulacao ILIKE '%");
					sql.append(professor.getTitulacao());
					sql.append("%'");
				}
				//Adiciona � busca o par�metro (pes_id)
				if(professor.getId() > 0) {
					sql.append(" AND pessoa.pes_id = ");
					sql.append(professor.getId());
				}
				//Adiciona � busca o par�metro (pes_email)
				if(professor.getEmail() != null) {
					sql.append(" AND pessoa.pes_email ILIKE '%"); 
					sql.append(professor.getEmail());
					sql.append("%'");
				}
				//Adiciona � busca o par�metro (pes_nome)
				if(professor.getNome() != null) {
					sql.append(" AND pessoa.pes_nome ILIKE '%"); 
					sql.append(professor.getNome());
					sql.append("%'");
				}
				//Adiciona � busca o par�metro (pes_cpf)
				if(professor.getCpf() != null) {
					sql.append(" AND pessoa.pes_cpf ILIKE '%"); 
					sql.append(professor.getCpf());
					sql.append("%'");
				}
				
				sql.append(" ORDER BY professor.pro_id");
				
				try {
					pst = connection.prepareStatement(sql.toString());
					
					rs = pst.executeQuery();
					
					List<EntidadeDominio> professores = new ArrayList<EntidadeDominio>();
					while(rs.next()) {
						professor = new Professor();
						
						professor.setId(rs.getInt("pes_id"));
						professor.setEmail(rs.getString("pes_email"));
						professor.setNome(rs.getString("pes_nome"));
						professor.setCpf(rs.getString("pes_cpf"));
						professor.setCodigo(rs.getInt("pro_id"));
						professor.setTitulacao(rs.getString("pro_titulacao"));
						
						professores.add(professor);
					}//while
					return professores;
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					try {
						pst.close();
						if(ctrlTransaction == true) {
							connection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}	
				
				return null;
			}//consultar	
}//class
