package br.com.brazcubas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.brazcubas.model.*;

public class AlunoDAO extends AbstractJdbcDAO {

	//tabela principal
	private static final String principal_name_table = "pessoa";
	private static final String principal_id_table = "pes_id";
	//subdivis�o 1 - aluno
	private static final String name_table = "aluno";
	private static final String id_table = "aln_id";
	//subdivis�o 2 - telefone
	private static final String sub2_name_table = "telefone";
	private static final String sub2_id_table = "tel_id";
	
	//Variaveis
	Telefone telefone = new Telefone();
	ArrayList<Telefone> telefones = new ArrayList<Telefone>();
	
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public AlunoDAO() {
		super(name_table, id_table);
	}
	
	public AlunoDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(EntidadeDominio entidadedominio) throws SQLException {
		//abrindo conex�o
		if(connection == null) {
			openConnection();
		}
		//Declarando Entidade de Dominio
		Aluno aluno = (Aluno)entidadedominio;
		//Persistindo informa��es Pessoa
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			//Constru��o de c�digo sql para inser��o no BD
			sql.append("INSERT INTO ");
			sql.append(principal_name_table);
			sql.append("(pes_cpf, pes_email, pes_nome, pes_isaluno) ");
			sql.append("VALUES (?,?,?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setString(1, aluno.getCpf());
			pst.setString(2, aluno.getEmail());
			pst.setString(3, aluno.getNome());
			pst.setBoolean(4, aluno.isStatus());			
			
			pst.executeUpdate();
			//Obtendo chave prim�ria gerada no BD
			rs = pst.getGeneratedKeys();
			int cdgPessoa= 0;
			if(rs.next())
				cdgPessoa= rs.getInt(1);
			aluno.setId(cdgPessoa);
			//comitando informa��es pessoais
			connection.commit();
	
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro ao persistir PESSOA");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} try {
								
			StringBuilder sql2 = new StringBuilder();
			//Constru��o de c�digo sql para inser��o no BD
			sql2.append("INSERT INTO ");
			sql2.append(name_table);
			sql2.append("(pes_id, aln_curso, aln_status)");
			sql2.append("VALUES (?,?,?);");
		
			pst = connection.prepareStatement(sql2.toString(), Statement.RETURN_GENERATED_KEYS);
		
			pst.setInt(1, aluno.getId());
			pst.setString(2, aluno.getCurso());
			pst.setBoolean(3, aluno.isStatus());			
		
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int cdgAluno= 0;
			if(rs.next())
				cdgAluno= rs.getInt(1);
			aluno.setCodigo(cdgAluno);
			connection.commit();
		
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro ao persistir ALUNO");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} try {
			//Instanciando array de telefones
			telefones = aluno.getTelefones();
			
			//adicionando telefone
			for (Telefone tels: telefones) { 
			
				StringBuilder sql2 = new StringBuilder();
				//Constru��o de c�digo sql para inser��o no BD
				sql2.append("INSERT INTO ");
				sql2.append(sub2_name_table);
				sql2.append("(pes_id, tel_tipo, tel_numero)");
				sql2.append("VALUES (?,?,?);");
			
				pst = connection.prepareStatement(sql2.toString(), Statement.RETURN_GENERATED_KEYS);
			
				pst.setInt(1, aluno.getId());
				pst.setString(2, tels.getTipo());
				pst.setString(3, tels.getNumero());			
			
				pst.executeUpdate();

				rs = pst.getGeneratedKeys();
				int cdgTelefone= 0;
				if(rs.next())
					cdgTelefone= rs.getInt(1);
				tels.setCodigo(cdgTelefone);
				connection.commit();
			}//
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro ao persistir TELEFONE");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			} finally {
			try {
				//fechando conex�o em caso de �xito da terceira opera��o 
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
	}//salvar
	@Override
	public void alterar(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
		if(connection == null) {
			openConnection();
		}
		//Casting Entidade de Dominio
		Aluno aluno = (Aluno)entidadedominio;
		//Alterando dados da Pessoa
		try {
			connection.setAutoCommit(false);
			//Constru��o de c�digo sql para opera��o de altera��o no BD
			StringBuilder sql = new StringBuilder();
			
			sql.append("UPDATE ");
			sql.append(principal_name_table);
			sql.append(" SET ");
			sql.append("(pes_nome, pes_email)");
			sql.append(" = (?,?) ");
			sql.append("WHERE ");
			sql.append(principal_id_table);
			sql.append("=(?)");
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, aluno.getNome());
			pst.setString(2, aluno.getEmail());
			pst.setInt(3, aluno.getId());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("ERRO AO ALTERAR INFORMA��ES DE PESSOA");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("aln_curso");
			sql.append(" = (?) ");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, aluno.getCurso());
			pst.setInt(2, aluno.getCodigo());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro ao alterar curso");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}try {
			//Instanciando array de telefones
			telefones = aluno.getTelefones();
			
			//alterando telefones
			for (Telefone tels: telefones) {
			
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			sql.append("UPDATE ");
			sql.append(sub2_name_table);
			sql.append(" SET ");
			sql.append("(tel_tipo, tel_numero)");
			sql.append(" = (?,?) ");
			sql.append("WHERE ");
			sql.append(sub2_id_table);
			sql.append("=(?)");
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, tels.getTipo());
			pst.setString(2, tels.getNumero());
			pst.setInt(3, tels.getCodigo());
			
			pst.executeUpdate();
			
			connection.commit();
			}//for
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro ao alterar telefone");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}//alterar
	@Override
	public void excluir(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
		if(connection == null) {
			openConnection();
		}
		//Casting EntidadeDominio
		Aluno aluno = (Aluno)entidadedominio;
		//Constru��o de comando SQL para opera��o de exclus�o
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, aluno.getCodigo());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("ERRO AO EXCLUIR ALUNO");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} try {
			//Alterando 'pes_isAluno' para FALSE, ap�s exclus�o de aluno
			//Desta forma caso 'aluno' tamb�m seja professor, seu registro nao ser� comprometido
			connection.setAutoCommit(false);
			//Constru��o de c�digo sql para altera��o de status na tabela 'PESSOA'
			StringBuilder sql = new StringBuilder();
			
			sql.append("UPDATE ");
			sql.append(principal_name_table);
			sql.append(" SET ");
			sql.append("pes_isaluno");
			sql.append(" = (?) ");
			sql.append("WHERE ");
			sql.append(principal_id_table);
			sql.append("=(?)");
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setBoolean(1, false);
			pst.setInt(2, aluno.getId());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.out.println("Erro de altera��o de status");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			
		} finally {
			try {
				//Fechando conex�o caso haja �xito nas opera��es
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
	}//excluir
	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidadedominio) throws SQLException {
		//Abrindo conex�o
		if(connection == null) {
			openConnection();
		}
		//Casting Entidade dom�nio para Aluno
		Aluno aluno = (Aluno)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(principal_name_table);
		sql.append(" natural join ");
		sql.append(name_table);
		sql.append(" natural join ");
		sql.append(sub2_name_table);
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		//Adiciona � busca o par�metro (aln_id)
		if(aluno.getCodigo() > 0) {
			sql.append(" AND aluno.aln_id = ");
			sql.append(aluno.getCodigo());
		}
		//Adiciona � busca o par�metro (aln_curso)
		if(aluno.getCurso() != null) {
			sql.append(" AND aluno.aln_curso ILIKE '%");
			sql.append(aluno.getCurso());
			sql.append("%'");
		}
		//Adiciona � busca o par�metro (pes_id)
		if(aluno.getId() > 0) {
			sql.append(" AND pessoa.pes_id = ");
			sql.append(aluno.getId());
		}
		//Adiciona � busca o par�metro (pes_email)
		if(aluno.getEmail() != null) {
			sql.append(" AND pessoa.pes_email ILIKE '%"); 
			sql.append(aluno.getEmail());
			sql.append("%'");
		}
		//Adiciona � busca o par�metro (pes_nome)
		if(aluno.getNome() != null) {
			sql.append(" AND pessoa.pes_nome ILIKE '%"); 
			sql.append(aluno.getNome());
			sql.append("%'");
		}
		//Adiciona � busca o par�metro (pes_cpf)
		if(aluno.getCpf() != null) {
			sql.append(" AND pessoa.pes_cpf ILIKE '%"); 
			sql.append(aluno.getCpf());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY aluno.aln_id");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<EntidadeDominio> alunos = new ArrayList<EntidadeDominio>();
			while(rs.next()) {
				aluno = new Aluno();
				
				aluno.setId(rs.getInt("pes_id"));
				aluno.setEmail(rs.getString("pes_email"));
				aluno.setNome(rs.getString("pes_nome"));
				aluno.setCpf(rs.getString("pes_cpf"));
				aluno.setCodigo(rs.getInt("aln_id"));
				aluno.setCurso(rs.getString("aln_curso"));
				
				alunos.add(aluno);
			}//while
			return alunos;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}//consultar
	
}//class


