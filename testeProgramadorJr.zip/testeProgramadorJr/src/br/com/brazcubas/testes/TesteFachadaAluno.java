package br.com.brazcubas.testes;

import java.util.ArrayList;

import br.com.brazcubas.control.*;
import br.com.brazcubas.model.Aluno;
import br.com.brazcubas.model.Telefone;
@SuppressWarnings("unused")
public class TesteFachadaAluno {

	public static void main(String[] args) {
		//Inicializando vari�veis de teste
		IFachada fachada = new FachadaAluno();
		Telefone tel1 = new Telefone();
		Telefone tel2 = new Telefone();
		ArrayList<Telefone> telefones = new ArrayList<Telefone>();
		//Instanciando variaveis de teste para telefone
		tel1.setNumero("11999990000");
		tel1.setCodigo(1);
		tel2.setNumero("1143545672");
		tel2.setCodigo(2);
		//Adicionando intes ao Array de telefones
			
		Aluno aluno = new Aluno("Oracio","12332112301","oracio@gmail.com"); //alterar cpf para realizar novos testes
		aluno.setTelefones(tel1);
		aluno.setTelefones(tel2);
		aluno.setCurso("AGRONEGOCIO");
		aluno.setCodigo(15);
		aluno.setId(36);
	
		
		Aluno outroAluno = new Aluno();
		outroAluno.setNome("Ricardo");
		
		//System.out.println(aluno.isStatus());
		//System.out.println(fachada.excluir(aluno) + " " + aluno.getId());
		System.out.println(fachada.alterar(aluno));
		
		
		
	}//main
}
