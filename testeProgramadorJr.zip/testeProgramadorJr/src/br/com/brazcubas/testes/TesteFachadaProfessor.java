package br.com.brazcubas.testes;

import java.util.ArrayList;

import br.com.brazcubas.control.*;
import br.com.brazcubas.model.Aluno;
import br.com.brazcubas.model.Professor;
import br.com.brazcubas.model.Telefone;

public class TesteFachadaProfessor {
	
@SuppressWarnings("unused")
public static void main(String[] args) {
	//Inicializando vari�veis de teste
			IFachada fachada = new FachadaProfessor();
			Telefone tel1 = new Telefone();
			Telefone tel2 = new Telefone();
			ArrayList<Telefone> telefones = new ArrayList<Telefone>();
			//Instanciando variaveis de teste para telefone
			tel1.setNumero("11999990000");
			tel1.setCodigo(3);
			tel2.setNumero("1199988889");
			tel2.setCodigo(4);
			//Adicionando intes ao Array de telefones
				
			Professor professor = new Professor("Oracio","19332112301","oracio@gmail.com","mestre"); //alterar cpf para realizar novos testes
			professor.setTelefones(tel1);
			professor.setTelefones(tel2);
			professor.setCodigo(15);
			professor.setId(36);
		
			Aluno outroAluno = new Aluno();
			outroAluno.setNome("Ricardo");
			
			//System.out.println(professor.isStatus());
			//System.out.println(fachada.excluir(professor) + " " + professor.getId());
			System.out.println(fachada.alterar(professor));
	}//main

}
