package br.com.brazcubas.model;

public class Professor extends Pessoa{

	private int codigo;
	private String titulacao;
	private boolean status;
	

	//Construtores e sobrecarga de m�todo
	public Professor() {
		
	}
	public Professor(String cpf) {
		setCpf(cpf);
	}
	public Professor(String nome,String cpf, String email, String titulacao) {
		setNome(nome);
		setCpf(cpf);
		setEmail(email);
		setTitulacao(titulacao);
		setStatus(true);
	}
	//sobrecarga e reescrita de m�todo
	public String toString() {
		
		 return ("|ID: "+ getId() + 
							" |Nome: " + getNome() + 
							" |CPF: " + getCpf()+
							" |E-mail: " + getEmail()+
							"/n|C�d.: " + getCodigo()+
							" |Titula��o: " + getTitulacao()+
							"\n");
	}
	
	//getters and setters
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getTitulacao() {
		return titulacao;
	}
	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public void addTelefone(String telefone) {
		
		
	}
	
	//Valida��es
	//Verifica se o campo Email � nulo ou vazio
	//retornando FALSE caso a vari�vel n�o tenha sido preenchida
	public boolean validaTitulacao(String titulacao){
		
		if(titulacao != null && !titulacao.equals("")) {
		
		return true;
		} else {
			return false;
		}
	}


	
	
}
