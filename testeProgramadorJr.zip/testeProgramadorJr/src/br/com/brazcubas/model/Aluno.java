package br.com.brazcubas.model;

public class Aluno extends Pessoa{
	
	private int codigo;
	private String curso;
	private boolean status;
	
	//Construtores e sobrecarga de m�todo
	public Aluno() {
		
	}
	public Aluno(String cpf) {
		setCpf(cpf);
	}
	public Aluno(String nome,String cpf, String email) {
		setNome(nome);
		setCpf(cpf);
		setEmail(email);
		setStatus(true);
	}
	//sobrecarga e rescrita de m�todo
	public String toString() {
		
		 return ("|ID: "+ getId() + 
							" |Nome: " + getNome() + 
							" |CPF: " + getCpf()+
							" |E-mail: " + getEmail()+
							" |RGM: " + getCodigo()+
							" |Curso: " + getCurso()+
							"\n");
	}
	
	//getters and setters
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	//Valida��es
	
	//Verifica se o campo Email � nulo ou vazio
	//retornando FALSE caso a vari�vel n�o tenha sido preenchida
	public boolean validaCurso(String curso){
		
		if(curso != null && !curso.equals("")) {
		
		return true;
		} else {
			return false;
		}
	}
	

}
