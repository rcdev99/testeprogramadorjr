package br.com.brazcubas.model;

public class Telefone {

	private int codigo;
	private String tipo;
	private String numero;
	
	//Construtores
	public Telefone(String numero) {
		tipo = "Indefinido";
		this.numero = numero;
	}
	public Telefone() {
		tipo = "Indefinido";
	}
	//Sobreescrita e sobrecarga de metodos
	public String toString() {
		
		return ("Tipo: " + getTipo() + "|" + "N�mero: " + getNumero());
	}
	
	
	//getter e setters
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
	
}
