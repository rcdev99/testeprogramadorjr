package br.com.brazcubas.model;

import java.util.ArrayList;

public class Pessoa extends EntidadeDominio{

	private int id;
	private String cpf;
	private String nome;
	private String email;
	private ArrayList<Telefone> telefones = new ArrayList<Telefone>();
	
	//getters and setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public ArrayList<Telefone> getTelefones() {
		return telefones;
	}
	public void setTelefones(Telefone telefones) {
		this.telefones.add(telefones);
	}
	
	//Valida�oes
	//Verifica se o campo CPF � nulo ou vazio
	//retornando FALSE caso a vari�vel n�o tenha sido preenchida
	public boolean validaCpf(String cpf){
		
		if(cpf != null && !cpf.equals("")) {
		
		return true;
		} else {
			return false;
		}
		
	}
	//Verifica se o campo Nome � nulo ou vazio
	//retornando FALSE caso a vari�vel n�o tenha sido preenchida
	public boolean validaNome(String nome){
		
		if(cpf != null && !cpf.equals("")) {
		
		return true;
		} else {
			return false;
		}
	}
	//Verifica se o campo Email � nulo ou vazio
	//retornando FALSE caso a vari�vel n�o tenha sido preenchida
	public boolean validaEmail(String email){
		
		if(cpf != null && !cpf.equals("")) {
		
		return true;
		} else {
			return false;
		}
	}
	
	
	
	
}
