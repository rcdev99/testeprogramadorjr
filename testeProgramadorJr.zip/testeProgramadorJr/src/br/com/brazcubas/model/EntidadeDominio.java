package br.com.brazcubas.model;

public class EntidadeDominio {

}
