package br.com.brazcubas.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.brazcubas.control.FachadaAluno;
import br.com.brazcubas.control.IFachada;
import br.com.brazcubas.model.*;

/**
 * Servlet implementation class adicionaAluno
 */
@WebServlet(name="Adionar Aluno", urlPatterns="/novo-aluno")
public class AdicionaAluno extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdicionaAluno() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Instanciando as vari�veis a serem utilizadas
		IFachada fachada = new FachadaAluno();
		Aluno aluno = new Aluno();
		String operacao = " ";
		Telefone telefone = new Telefone();
		//Definindo caminho da p�gina html
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("html/novo-aluno.html");
		//Mensagem de verifica��o
		System.out.println("Rodando Servlet addAluno");
		try {
			
			rd.forward(request, response);
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		//capturando dados 
		String nome= request.getParameter("nome");
		String cpf= request.getParameter("cpf");
		String curso= request.getParameter("curso");
		String email= request.getParameter("email");
		String[] telefones = request.getParameterValues("telefone");
		operacao = request.getParameter("operacao");
		if (operacao.equals("salvar")){
		
		//construindo objeto
				aluno.setNome(nome);
				aluno.setCpf(cpf);
				aluno.setCurso(curso);
				aluno.setEmail(email);
		//adicionando telefone
		for(int i=0; i<telefones.length; i++) { 
			String tel = telefones[i];
				telefone.setNumero(tel);
		}
				aluno.setTelefones(telefone);
		//executa os comandos para salvar aluno
		System.out.println(fachada.salvar(aluno));		
				
		//Exibindo dados cadastrados		
		System.out.println(aluno.toString());
			
		}	
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
