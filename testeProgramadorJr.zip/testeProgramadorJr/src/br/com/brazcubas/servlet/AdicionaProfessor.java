package br.com.brazcubas.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import br.com.brazcubas.control.FachadaProfessor;
import br.com.brazcubas.control.IFachada;
import br.com.brazcubas.model.Professor;
import br.com.brazcubas.model.Telefone;

/**
 * Servlet implementation class adicionaProfessor
 */
@WebServlet(name="/adicionaProfessor", urlPatterns="/novo-professor")
public class AdicionaProfessor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdicionaProfessor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Instanciando as vari�veis a serem utilizadas
		IFachada fachada = new FachadaProfessor();
		Professor professor = new Professor();
		Telefone telefone = new Telefone();
		//Definindo caminho da p�gina html
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("html/novo-professor.html");
		//Mensagem de verifica��o
		System.out.println("Rodando Servlet addProfessor");
		try {
			
			rd.forward(request, response);
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		//capturando dados 
		String nome= request.getParameter("nome");
		String cpf= request.getParameter("cpf");
		String titulacao= request.getParameter("titulo");
		String email= request.getParameter("email");
		String[] telefones = request.getParameterValues("telefone");
		String operacao = request.getParameter("operacao");
		if (operacao.equals("salvar")){
		
		//construindo objeto
				professor.setNome(nome);
				professor.setCpf(cpf);
				professor.setTitulacao(titulacao);
				professor.setEmail(email);
		//adicionando telefone � Array de Telefone(s)
		for(int i=0; i<telefones.length; i++) { 
			String tel = telefones[i];
				telefone.setNumero(tel);
		}
				professor.setTelefones(telefone);
		//executa os comandos para salvar professor
		System.out.println(fachada.salvar(professor));		
				
		//Exibindo dados cadastrados		
		System.out.println(professor.toString());
			
		}	
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
