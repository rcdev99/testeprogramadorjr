package br.com.brazcubas.control;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.brazcubas.model.*;
import br.com.brazcubas.dao.*;

public class FachadaProfessor implements IFachada {

	@Override
	public String salvar(EntidadeDominio entidadeDominio) {
		Professor professor = (Professor)entidadeDominio;
		//Executando valida��es
		//Valida CPF
		if(professor.validaCpf(professor.getCpf())){
			System.out.println("CPF PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CPF";
		}
		//Valida Curso
		if(professor.validaTitulacao(professor.getTitulacao())) {
			System.out.println("CAMPO CURSO PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO TITULACAO";
		}
		//Valida E-mail
		if(professor.validaEmail(professor.getEmail())) {
			System.out.println("CAMPO E-MAIL PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO E-MAIL";
		}
		//Valida Nome
		if(professor.validaNome(professor.getNome())) {
			System.out.println("CAMPO NOME PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO NOME";
		}
		
		//Instanciando DAO de Professor
		IDAO daoProfessor= new ProfessorDAO();
		try {
			daoProfessor.salvar(professor);
			return "PROFESSOR SALVO COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO SALVAR PROFESSOR";
		}
	}
	@Override
	public String alterar(EntidadeDominio entidadeDominio) {
		Professor professor = (Professor)entidadeDominio;
		//Executando valida��es
		//Valida CPF
		if(professor.validaCpf(professor.getCpf())){
			System.out.println("CPF PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CPF";
		}
		//Valida Curso
		if(professor.validaTitulacao(professor.getTitulacao())) {
			System.out.println("CAMPO CURSO PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO TITULACAO";
		}
		//Valida E-mail
		if(professor.validaEmail(professor.getEmail())) {
			System.out.println("CAMPO E-MAIL PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO E-MAIL";
		}
		//Valida Nome
		if(professor.validaNome(professor.getNome())) {
			System.out.println("CAMPO NOME PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO NOME";
		}
		
		//Instanciando DAO de Professor
		IDAO daoProfessor= new ProfessorDAO();
		try {
			daoProfessor.alterar(professor);
			return "PROFESSOR ALTERADO COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO ALTERRAR PROFESSOR";
		}
	}

	@Override
	public String excluir(EntidadeDominio entidadeDominio) {
		Professor professor = (Professor)entidadeDominio;
		IDAO daoProfessor= new ProfessorDAO();
		try {
			daoProfessor.excluir(professor);
			return "EXCLUS�O REALIZADA COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO EXECUTAR EXCLUS�O!";
		}
	}

	@SuppressWarnings("unused")
	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidadeDominio) {
		Professor professor = (Professor)entidadeDominio;
		IDAO daoProf = new ProfessorDAO();
		List<EntidadeDominio> professores = new ArrayList<EntidadeDominio>();
		
		try {
			professores = daoProf.consultar(professor);
			for (EntidadeDominio prof1: professores) {
				//System.out.println(prof1.toString());
			};
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return professores;
	}

}
