package br.com.brazcubas.control;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.brazcubas.model.*;
import br.com.brazcubas.dao.*;

public class FachadaAluno implements IFachada {

	@Override
	public String salvar(EntidadeDominio entidadeDominio) {
		Aluno aluno= (Aluno)entidadeDominio;
		//Executando valida��es
		//Valida CPF
		if(aluno.validaCpf(aluno.getCpf())){
			System.out.println("CPF PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CPF";
		}
		//Valida Curso
		if(aluno.validaCurso(aluno.getCurso())) {
			System.out.println("CAMPO CURSO PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CURSO";
		}
		//Valida E-mail
		if(aluno.validaEmail(aluno.getEmail())) {
			System.out.println("CAMPO E-MAIL PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO E-MAIL";
		}
		//Valida Nome
		if(aluno.validaNome(aluno.getNome())) {
			System.out.println("CAMPO NOME PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO NOME";
		}
		
		//Instanciando DAO de Aluno
		IDAO daoAluno= new AlunoDAO();
		try {
			daoAluno.salvar(aluno);
			return "ALUNO SALVO COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO SALVAR ALUNO";
		}
	}
	@Override
	public String alterar(EntidadeDominio entidadeDominio) {
		//Executando Casting
		Aluno aluno = (Aluno)entidadeDominio;
		//Executando valida��es
		//Valida CPF
		if(aluno.validaCpf(aluno.getCpf())){
			System.out.println("CPF PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CPF";
		}
		//Valida Curso
		if(aluno.validaCurso(aluno.getCurso())) {
			System.out.println("CAMPO CURSO PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO CURSO";
		}
		//Valida E-mail
		if(aluno.validaEmail(aluno.getEmail())) {
			System.out.println("CAMPO E-MAIL PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO E-MAIL";
		}
		//Valida Nome
		if(aluno.validaNome(aluno.getNome())) {
			System.out.println("CAMPO NOME PREENCHIDO");
		}else {
			return "PREENCHA CORRETAMENTO O CAMPO NOME";
		}
		//Instanciando DAO de Aluno
		IDAO daoAluno = new AlunoDAO();
		try {
			daoAluno.alterar(aluno);
			return "ALUNO ALTERADO COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO ALTERAR ALUNO";
		}
	}

	@Override
	public String excluir(EntidadeDominio entidadeDominio) {
		Aluno aluno = (Aluno)entidadeDominio;
		IDAO daoAluno = new AlunoDAO();
		try {
			daoAluno.excluir(aluno);
			return "ALUNO EXCLUIDO COM SUCESSO!";
		} catch (SQLException e) {
			return "ERRO AO EXCLUIR ALUNO!";
		}
	}
	@SuppressWarnings("unused")
	@Override
	public List<EntidadeDominio> consultar(EntidadeDominio entidadeDominio) {
		Aluno aluno= (Aluno)entidadeDominio;
		IDAO daoAluno = new AlunoDAO();
		List<EntidadeDominio> alunos = new ArrayList<EntidadeDominio>();
		
		try {
			alunos = daoAluno.consultar(aluno);
			for (EntidadeDominio aluno1: alunos) {
				//System.out.println(aluno1.toString());
			};
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return alunos;
	}

}
