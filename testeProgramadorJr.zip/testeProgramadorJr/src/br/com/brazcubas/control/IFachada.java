package br.com.brazcubas.control;

import java.util.List;

import br.com.brazcubas.model.*;;

public interface IFachada {
	public String salvar(EntidadeDominio entidadeDominio);
	public String alterar(EntidadeDominio entidadeDominio);
	public String excluir(EntidadeDominio entidadeDominio);
	public List<EntidadeDominio> consultar(EntidadeDominio entidadeDominio);
}
